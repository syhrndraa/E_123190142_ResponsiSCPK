%mengambil seluruh data yang ada pada kolom 3, 4, dan 5
opts = detectImportOptions('Real Estate Valuation Data Set.xlsx');
opts.SelectedVariableNames = (3:5);
kolom35 = readmatrix('Real Estate Valuation Data Set.xlsx',opts);

%mengambil seluruh data yang ada pada kolom 8
opts = detectImportOptions('Real Estate Valuation Data Set.xlsx');
opts.SelectedVariableNames = (8);
kolom8 = readmatrix('Real Estate Valuation Data Set.xlsx',opts);

data = [kolom35 kolom8];
data=data(1:50,:);%mengambil 50 baris data dan semua kolom pada matrix data

k = [0,0,1,0];%kriteria, yaitu 1=atribut benefit, dan  0= atribut cost
w = [3,5,4,1];%Nilai bobot tiap untuk setiap kriteria -> ditentukan berdasarkan soal 

%tahapan pertama, perbaikan bobot
[m n]=size (data); %inisialisasi ukuran x
w=w./sum(w); %membagi bobot per kriteria dengan jumlah total seluruh bobot

%tahapan kedua, melakukan perhitungan vektor(S) per baris (alternatif)
for j=1:n,
    if k(j)==0, w(j)=-1*w(j);
    end;
end;
for i=1:m,
    S(i)=prod(data(i,:).^w);
end;

%tahapan ketiga, proses perangkingan
V= S/sum(S);

Vt=V.';%transpose matrix V
opts = detectImportOptions('Real Estate Valuation Data Set.xlsx');
opts.SelectedVariableNames = (1);%mengambil kolom satu (nomor rumah) untuk perankingan
dataFix= readmatrix('Real Estate Valuation Data Set.xlsx',opts);
dataFix=dataFix(1:50,1);%mengambil 50 baris (50 data) dan seluruh kolom (kolom nomor rumah)
dataFix=[dataFix Vt];
dataFix=sortrows(dataFix,-2);%dilakukan perankingan
dataFix = dataFix(1:5,1);%mengambil data untuk 5 rumah teratas dengan kolom pertama(nomor rumah)
disp ('5 nomor real estate teratas berdasarkan hasil pe-rankingan yang paling direkomendasikan =')
disp (dataFix)